DROP TABLE Organisme CASCADE CONSTRAINTS;
DROP TABLE Repas CASCADE CONSTRAINTS;
DROP TABLE Aliment CASCADE CONSTRAINTS;
DROP TABLE Sauce CASCADE CONSTRAINTS;
DROP TABLE Ingredient CASCADE CONSTRAINTS;
DROP TABLE Machine CASCADE CONSTRAINTS;
DROP TABLE Grade CASCADE CONSTRAINTS;
DROP TABLE Rang CASCADE CONSTRAINTS;
DROP TABLE Titre CASCADE CONSTRAINTS;
DROP TABLE Dignite CASCADE CONSTRAINTS;
DROP TABLE TenracClub CASCADE CONSTRAINTS;
DROP TABLE Legume CASCADE CONSTRAINTS;
DROP TABLE Croyances CASCADE CONSTRAINTS;
DROP TABLE Allergènes CASCADE CONSTRAINTS;
DROP TABLE Boisson CASCADE CONSTRAINTS;
DROP TABLE ConstituantRepas CASCADE CONSTRAINTS;
DROP TABLE Tenrac CASCADE CONSTRAINTS;
DROP TABLE Reunion CASCADE CONSTRAINTS;
DROP TABLE Plat CASCADE CONSTRAINTS;
DROP TABLE Entree CASCADE CONSTRAINTS;
DROP TABLE Dessert CASCADE CONSTRAINTS;
DROP TABLE Participe CASCADE CONSTRAINTS;
DROP TABLE ComposeDe CASCADE CONSTRAINTS;
DROP TABLE AccompagnéDe CASCADE CONSTRAINTS;
DROP TABLE Contient CASCADE CONSTRAINTS;
DROP TABLE Entretien CASCADE CONSTRAINTS;
DROP TABLE Peut_heurter CASCADE CONSTRAINTS;
DROP TABLE Peut_provoquer CASCADE CONSTRAINTS;
DROP TABLE Recquiert CASCADE CONSTRAINTS;
DROP TABLE Propose CASCADE CONSTRAINTS;
DROP TABLE Note CASCADE CONSTRAINTS;

create table ORGANISME
(
    IDORGANISME   NUMBER(10)    not null
        constraint PK_ORGANISME
            primary key,
    RAISONSOCIALE VARCHAR2(100) not null,
    SIRET         CHAR(16)      not null
)
/

create table REPAS
(
    IDREPAS NUMBER(10)    not null
        constraint PK_REPAS
            primary key,
    LIBELLE VARCHAR2(250) not null
)
/

create table ALIMENT
(
    IDALIMENT  NUMBER(10) not null
        constraint PK_ALIMENT
            primary key,
    NOMALIMENT VARCHAR2(50)
)
/

create table SAUCE
(
    IDSAUCE  NUMBER(10)   not null
        constraint PK_SAUCE
            primary key,
    NOMSAUCE VARCHAR2(50) not null
)
/

create table INGREDIENT
(
    IDINGREDIENT  NUMBER(10)   not null
        constraint PK_INGREDIENT
            primary key,
    NOMINGREDIENT VARCHAR2(50) not null
)
/

create table MACHINE
(
    IDMACHINE     NUMBER(10)    not null
        constraint PK_MACHINE
            primary key,
    NOMMACHINE    VARCHAR2(50)  not null,
    MODELEMACHINE VARCHAR2(100) not null
)
/

create table GRADE
(
    IDGRADE  NUMBER(10)   not null
        constraint PK_GRADE
            primary key,
    NOMGRADE VARCHAR2(50) not null
)
/

create table RANG
(
    IDRANG  NUMBER(10)   not null
        constraint PK_RANG
            primary key,
    NOMRANG VARCHAR2(50) not null
)
/

create table TITRE
(
    IDTITRE  NUMBER(10)   not null
        constraint PK_TITRE
            primary key,
    NOMTITRE VARCHAR2(50) not null
)
/

create table DIGNITE
(
    IDDIGNITE  NUMBER(10)   not null
        constraint PK_DIGNITE
            primary key,
    NOMDIGNITE VARCHAR2(50) not null
)
/

create table TENRACCLUB
(
    IDCLUB   NUMBER(10)   not null
        constraint PK_TENRACCLUB
            primary key,
    NOMCLUB  VARCHAR2(50) not null
        constraint UK_TENRACCLUB_01
            unique,
    IDCLUB_1 NUMBER(10)
        constraint FK_TENRACCLUB_TENRACCLUBPERE
            references TENRACCLUB
)
/

create table LEGUME
(
    IDALIMENT NUMBER(10) not null
        constraint PK_LEGUME
            primary key
        constraint FK_LEGUME_ALIMENT
            references ALIMENT
)
/

create table CROYANCES
(
    IDCROYANCES  NUMBER(10) not null
        constraint PK_CROYANCES
            primary key,
    NOMCROYANCES VARCHAR2(50)
)
/

create table ALLERGENE
(
    IDALLERGENE  NUMBER(10) not null
        constraint PK_ALLERGENE
            primary key,
    NOMALLERGENE VARCHAR2(50)
)
/

create table BOISSON
(
    IDBOISSON   NUMBER(10) not null
        constraint PK_BOISSON
            primary key,
    NOMBOISSON  VARCHAR2(50),
    TYPEBOISSON VARCHAR2(50)
)
/

create table CONSTITUANTREPAS
(
    IDCONSTITUANTREPAS NUMBER(10) not null
        constraint PK_CONSTITUANTREPAS
            primary key
)
/

create table TENRAC
(
    IDTENRAC       NUMBER(10)    not null
        constraint PK_TENRAC
            primary key,
    NOM            VARCHAR2(50)  not null,
    PRENOM         VARCHAR2(50)  not null,
    COURRIEL       VARCHAR2(50)  not null
        constraint UK_TENRAC_01
            unique,
    TELEPHONE      VARCHAR2(20)  not null
        constraint UK_TENRAC_02
            unique,
    ADRESSEPOSTALE VARCHAR2(255) not null,
    IDCLUB         NUMBER(10)
        constraint FK_TENRAC_TENRACCLUB
            references TENRACCLUB,
    IDDIGNITE      NUMBER(10)
        constraint FK_TENRAC_DIGNITE
            references DIGNITE,
    IDGRADE        NUMBER(10)    not null
        constraint FK_TENRAC_GRADE
            references GRADE,
    IDTITRE        NUMBER(10)
        constraint FK_TENRAC_TITRE
            references TITRE,
    IDRANG         NUMBER(10)
        constraint FK_TENRAC_RANG
            references RANG,
    IDORGANISME    NUMBER(10)
        constraint FK_TENRAC_ORGANISME
            references ORGANISME,
    AGE            NUMBER(3)
)
/

create table PLAT
(
    IDCONSTITUANTREPAS NUMBER(10)   not null
        constraint PK_PLAT
            primary key
        constraint FK_PLAT_CONSTITUANTREPAS
            references CONSTITUANTREPAS,
    NOMPLAT            VARCHAR2(50) not null
        constraint UK_PLAT_01
            unique
)
/

create table ENTREE
(
    IDCONSTITUANTREPAS NUMBER(10)   not null
        constraint PK_ENTREE
            primary key
        constraint FK_ENTREE_CONSTITUANTREPAS
            references CONSTITUANTREPAS,
    NOMENTREE          VARCHAR2(75) not null
        constraint UK_ENTREE_01
            unique
)
/

create table DESSERT
(
    IDCONSTITUANTREPAS NUMBER(10)   not null
        constraint PK_DESSERT
            primary key
        constraint FK_DESSERT_CONSTITUANTREPAS
            references CONSTITUANTREPAS,
    NOMDESSERT         VARCHAR2(75) not null
        constraint UK_DESSERT_01
            unique
)
/

create table PARTICIPE
(
    IDTENRAC  NUMBER(10) not null
        constraint FK_PARTICIPE_TENRAC
            references TENRAC,
    IDREUNION NUMBER(10) not null,
    constraint PK_PARTICIPE
        primary key (IDTENRAC, IDREUNION)
)
/

create table COMPOSEDE
(
    IDREPAS            NUMBER(10) not null
        constraint FK_COMPOSEDE_REPAS
            references REPAS,
    IDCONSTITUANTREPAS NUMBER(10) not null
        constraint FK_COMPOSEDE_CONSTITUANTREPAS
            references CONSTITUANTREPAS,
    constraint PK_COMPOSEDE
        primary key (IDREPAS, IDCONSTITUANTREPAS)
)
/

create table ESTCONSTITUE
(
    IDALIMENT          NUMBER(10) not null
        constraint FK_ESTCONSTITUE_ALIMENT
            references ALIMENT,
    IDCONSTITUANTREPAS NUMBER(10) not null
        constraint FK_ESTCONSITUE_CONSTITUANTREPAS
            references CONSTITUANTREPAS,
    constraint PK_ESTCONSTITUE
        primary key (IDALIMENT, IDCONSTITUANTREPAS)
)
/

create table ACCOMPAGNEDE
(
    IDCONSTITUANTREPAS NUMBER(10) not null
        constraint FK_ACCOMPAGNEDE_PLAT
            references PLAT,
    IDSAUCE            NUMBER(10) not null
        constraint FK_ACCOMPAGNEDE_SAUCE
            references SAUCE,
    constraint PK_ACCOMPAGNEDE
        primary key (IDCONSTITUANTREPAS, IDSAUCE)
)
/

create table CONTIENT
(
    IDSAUCE      NUMBER(10) not null
        constraint FK_CONTIENT_SAUCE
            references SAUCE,
    IDINGREDIENT NUMBER(10) not null
        constraint FK_CONTIENT_INGREDIENT
            references INGREDIENT,
    constraint PK_CONTIENT
        primary key (IDSAUCE, IDINGREDIENT)
)
/

create table ENTRETIEN
(
    IDTENRAC  NUMBER(10) not null
        constraint FK_ENTRETIEN_TENRAC
            references TENRAC,
    IDMACHINE NUMBER(10) not null
        constraint FK_ENTRETIEN_MACHINE
            references MACHINE,
    DATE_     DATE       not null,
    constraint ENTRETIEN_PK
        primary key (IDTENRAC, IDMACHINE, DATE_)
)
/

create table PEUT_HEURTER
(
    IDALIMENT   NUMBER(10) not null
        constraint FK_PEUT_HEURTER_ALIMENT
            references ALIMENT,
    IDCROYANCES NUMBER(10) not null
        constraint FK_PEUT_HEURTER_CROYANCES
            references CROYANCES,
    constraint PK_PEUT_HEURTER
        primary key (IDALIMENT, IDCROYANCES)
)
/

create table PEUT_PROVOQUER
(
    IDALIMENT   NUMBER(10) not null
        constraint FK_PEUT_PROVOQUER_ALIMENT
            references ALIMENT,
    IDALLERGENE NUMBER(10) not null
        constraint FK_PEUT_PROVOQUER_ALLERGENE
            references ALLERGENE,
    constraint PK_PEUT_PROVOQUER
        primary key (IDALIMENT, IDALLERGENE)
)
/

create table RECQUIERT
(
    IDCONSTITUANTREPAS NUMBER(10) not null
        constraint FK_RECQUIERT_PLAT
            references PLAT,
    IDMACHINE          NUMBER(10) not null
        constraint FK_RECQUIERT_MACHINE
            references MACHINE,
    constraint PK_RECQUIERT
        primary key (IDCONSTITUANTREPAS, IDMACHINE)
)
/

create table PROPOSE
(
    IDREPAS   NUMBER(10) not null
        constraint FK_PROPOSE_REPAS
            references REPAS,
    IDBOISSON NUMBER(10) not null
        constraint FK_PROPOSE_BOISSON
            references BOISSON,
    constraint PK_PROPOSE
        primary key (IDREPAS, IDBOISSON)
)
/

create table NOTE
(
    IDTENRAC NUMBER(10)    not null
        constraint FK_NOTE_TENRAC
            references TENRAC,
    IDREPAS  NUMBER(10)    not null
        constraint FK_NOTE_REPAS
            references REPAS,
    AVIS     VARCHAR2(200) not null,
    DATE_    DATE          not null,
    NOTE     NUMBER(2)     not null,
    constraint PK_NOTE
        primary key (IDTENRAC, IDREPAS)
)
/

create table POSSEDE
(
    IDTENRAC    NUMBER(10) not null
        references TENRAC,
    IDALLERGENE NUMBER(10) not null
        references ALLERGENE,
    primary key (IDTENRAC, IDALLERGENE)
)
/

create table CROIT
(
    IDTENRAC    NUMBER(10) not null
        references TENRAC,
    IDCROYANCES NUMBER(10) not null
        references CROYANCES,
    primary key (IDTENRAC, IDCROYANCES)
)
/

create table REUNION
(
    IDREUNION      NUMBER(10)   not null
        constraint PK_REUNION
            primary key,
    DATEREUNION    DATE,
    ADRESSEREUNION VARCHAR2(50) not null,
    IDTENRAC       NUMBER(10)   not null
        constraint FK_REUNION_TENRAC
            references TENRAC,
    IDREPAS        NUMBER(10)
        constraint FK_REUNION_REPAS
            references REPAS
)
/

